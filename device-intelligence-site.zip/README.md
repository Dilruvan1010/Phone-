# Device Intelligence Site

A starter full-stack device information platform.

## Structure
- `frontend/` — responsive UI
- `devices/` — one JSON file per device (GitHub-friendly)
- `backend/` — Node.js/Express API
- `backend/services/price.js` — price provider abstraction
- `backend/services/ai.js` — AI verification hook
- `backend/services/search.js` — web search hook
- `data/` — local dynamic price data for development

## Run
1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env`
4. `npm start`
5. Open `http://localhost:3000`

The included price/search/AI services are safe placeholders. Add real provider credentials and implement a provider that permits your intended use before calling it “live”.
